﻿class Program
{
    static void Main(string[] args)
    {
       
        int i = 0;
        int cum = 0;

        do
        {
            
            bool flag = int.TryParse(Console.ReadLine(), out i);

            if (flag == false)
            {
                i = -1;
                continue;
            }  
            if (i % 2 != 0 && i > 0)
                cum += i;
        } while (i!= 0);

        Console.WriteLine("Нечетные положительные числа:");
        Console.WriteLine("Сумма: " + cum);
        Console.ReadKey();
    }
}