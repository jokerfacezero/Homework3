﻿class Fraction 
{
    public int re;
    public int im;

    public Fraction Plus(Fraction x2)
    {
        Fraction Plus = new Fraction();
        Plus.re = x2.re + this.re;
        Plus.im = x2.im + this.im;
        return Plus;
    }

    public Fraction Minus(Fraction x2)
    {
        Fraction Minus = new Fraction();
        Minus.re =  this.re - x2.re;
        Minus.im =  this.im - x2.im;
        

        return Minus;
    }
    public Fraction MultiCation (Fraction x2)
    {
        Fraction MultiCation = new Fraction();
        MultiCation.re = x2.re * this.re;
        MultiCation.im = x2.im * this.im;
        return MultiCation;
    }
    public Fraction Division (Fraction x2)
    {
        Fraction Division = new Fraction();
        Division.re = this.re * x2.im;
        Division.im = this.im * x2.re;
        return Division;
    }
    public string ToString()
    {
        int count = 0;
        for (int i = 0; re >= im; i++)
        {
            if (re == im)
            {
                count++;
                break;
            }
            else if( re > im)
            {
                re = re - im;
                count++;
            }
        }
        if (re == 0 || im == 0)
        {
            return "Неверное значение, попробуйте снова";
        }
        if (re == im)
        {
            return " " + count;
        }
        else if (count > 0)
        {
            return "  " + re + "\n " + count + "=" + "\n " + " " + im;
        }
        
        else
        {
            return " " + re + "\n " + "=" + "\n " + "" + im;
        }    
    }


    static void Main (string[] args)
    {
        Fraction fract1 = new Fraction();
        fract1.re = 1;
        fract1.im = 2;
        Fraction fract2 = new Fraction();
        fract2.re = 2;
        fract2.im = 2;

        Fraction resultSum = fract1.Plus(fract2);
        Console.WriteLine (resultSum.ToString());
        Console.WriteLine();

        Fraction ResultMinus = fract1.Minus(fract2);
        Console.WriteLine(ResultMinus.ToString());
        Console.WriteLine();

        Fraction ResultMulti = fract1.MultiCation(fract2);
        Console.WriteLine(ResultMulti.ToString());
        Console.WriteLine();

        Fraction ResultDivis = fract1.Division(fract2);
        Console.WriteLine(ResultDivis.ToString());
        Console.WriteLine ();

        Console.ReadKey ();
    }
}
